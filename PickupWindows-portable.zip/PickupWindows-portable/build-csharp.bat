@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "FRAMEWORK_DIR=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319"
if not exist "%FRAMEWORK_DIR%\csc.exe" set "FRAMEWORK_DIR=%WINDIR%\Microsoft.NET\Framework\v4.0.30319"

if not exist "%FRAMEWORK_DIR%\csc.exe" (
  echo [ERROR] .NET Framework C# compiler csc.exe was not found.
  echo Install or enable .NET Framework 4.x, then run this file again.
  pause
  exit /b 1
)

set "WPF_DIR=%FRAMEWORK_DIR%\WPF"
if not exist "%WPF_DIR%\UIAutomationClient.dll" set "WPF_DIR=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\WPF"
if not exist "%WPF_DIR%\UIAutomationClient.dll" set "WPF_DIR=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\WPF"

if not exist "%WPF_DIR%\UIAutomationClient.dll" (
  echo [ERROR] UIAutomationClient.dll was not found.
  echo Install or enable .NET Framework 4.x, then run this file again.
  pause
  exit /b 1
)

"%FRAMEWORK_DIR%\csc.exe" /nologo /target:winexe /optimize+ /out:PickupWindows.exe ^
  /reference:System.dll ^
  /reference:System.Core.dll ^
  /reference:System.Drawing.dll ^
  /reference:System.Windows.Forms.dll ^
  /reference:System.Xml.dll ^
  /reference:"%WPF_DIR%\UIAutomationClient.dll" ^
  /reference:"%WPF_DIR%\UIAutomationTypes.dll" ^
  PickupWindows.cs

if errorlevel 1 (
  echo [ERROR] Build failed.
  pause
  exit /b 1
)

echo [OK] Built %CD%\PickupWindows.exe
exit /b 0
