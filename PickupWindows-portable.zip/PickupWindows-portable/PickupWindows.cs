using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Windows.Automation;
using System.Xml.Serialization;

namespace PickupWindows
{
    [Serializable]
    public class AppState
    {
        public List<ProjectItem> Projects = new List<ProjectItem>();
        public List<SessionItem> Sessions = new List<SessionItem>();
        public List<string> CustomScanFolders = new List<string>();
    }

    [Serializable]
    public class ProjectItem
    {
        public string Id;
        public string Name;
        public string Description;
        public string Status;
        public int SortOrder;
    }

    [Serializable]
    public class SessionResource
    {
        public string Id;
        public string Kind;
        public string Title;
        public string Value;
        public string CreatedAt;
    }

    [Serializable]
    public class SessionItem
    {
        public string Id;
        public string Source;
        public string Host;
        public string Title;
        public string TitleOverride;
        public string Cwd;
        public string LastActive;
        public string LastMessage;
        public string RawPath;
        public string LinkedProjectId;
        public bool Hidden;
        public List<SessionResource> Resources = new List<SessionResource>();

        public string DisplayTitle
        {
            get { return string.IsNullOrWhiteSpace(TitleOverride) ? (Title ?? "(no title)") : TitleOverride; }
        }
    }

    public class MainForm : Form
    {
        [DllImport("user32.dll")]
        private static extern int SetWindowCompositionAttribute(IntPtr hwnd, ref WindowCompositionAttributeData data);

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

        [StructLayout(LayoutKind.Sequential)]
        private struct WindowCompositionAttributeData
        {
            public int Attribute;
            public IntPtr Data;
            public int SizeOfData;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct AccentPolicy
        {
            public int AccentState;
            public int AccentFlags;
            public int GradientColor;
            public int AnimationId;
        }

        private readonly string dataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            ".sessiontracker");
        private readonly string codexDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            ".codex", "sessions");
        private readonly string claudeDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            ".claude", "projects");

        private AppState state = new AppState();
        private NotifyIcon tray;
        private ListBox projectList;
        private ListBox archivedList;
        private ListView sessionList;
        private FlowLayoutPanel sessionFeed;
        private Label titleLabel;
        private Label subtitleLabel;
        private Label statusLabel;
        private Timer foregroundTimer;
        private Timer scanTimer;
        private string lastForegroundKey;
        private string activeWindowFingerprint;
        private string activeWindowSessionId;
        private DateTime lastWindowSeenUtc = DateTime.MinValue;
        private bool allowExit;
        private readonly Color bg = Color.FromArgb(246, 247, 249);
        private readonly Color panelBg = Color.FromArgb(255, 255, 255);
        private readonly Color sidebarBg = Color.FromArgb(238, 240, 244);
        private readonly Color textMain = Color.FromArgb(29, 29, 31);
        private readonly Color textSubtle = Color.FromArgb(105, 105, 110);
        private readonly Color line = Color.FromArgb(222, 225, 230);
        private readonly Color accent = Color.FromArgb(0, 113, 227);
        private readonly Regex codexIdRegex = new Regex(
            @"rollout-.+-([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\.jsonl$",
            RegexOptions.Compiled);

        private string DataPath { get { return Path.Combine(dataDir, "pickup-windows.xml"); } }
        private string StartupBatPath
        {
            get
            {
                return Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.Startup),
                    "PickupWindows.bat");
            }
        }

        public MainForm()
        {
            Text = "Pickup";
            Size = new Size(520, 760);
            MinimumSize = new Size(460, 580);
            StartPosition = FormStartPosition.CenterScreen;
            Font = new Font("Microsoft YaHei UI", 9F);
            BackColor = Color.FromArgb(42, 44, 54);
            Opacity = 0.96;

            LoadState();
            BuildUi2();
            BuildTray();
            BuildForegroundTracker();
            TryEnableAcrylic();

            Shown += delegate
            {
                Activate();
                BeginInvoke(new Action(delegate
                {
                    ScanNow();
                    RefreshAll();
                }));
            };

            FormClosing += delegate(object sender, FormClosingEventArgs e)
            {
                if (!allowExit)
                {
                    e.Cancel = true;
                    Hide();
                    tray.ShowBalloonTip(900, "Pickup", "已隐藏到右下角托盘，双击图标可重新打开。", ToolTipIcon.Info);
                }
            };
        }

        private void TryEnableAcrylic()
        {
            try
            {
                var accent = new AccentPolicy();
                accent.AccentState = 4; // Acrylic blur behind on supported Windows builds.
                accent.AccentFlags = 2;
                accent.GradientColor = unchecked((int)0xCC30323C);
                int size = Marshal.SizeOf(accent);
                IntPtr ptr = Marshal.AllocHGlobal(size);
                Marshal.StructureToPtr(accent, ptr, false);
                var data = new WindowCompositionAttributeData();
                data.Attribute = 19;
                data.SizeOfData = size;
                data.Data = ptr;
                SetWindowCompositionAttribute(Handle, ref data);
                Marshal.FreeHGlobal(ptr);
            }
            catch
            {
                Opacity = 0.94;
            }
        }

        private void BuildUi2()
        {
            BackColor = Color.FromArgb(38, 40, 50);
            Padding = new Padding(1);

            var layout = new TableLayoutPanel();
            layout.Dock = DockStyle.Fill;
            layout.ColumnCount = 1;
            layout.RowCount = 3;
            layout.BackColor = Color.FromArgb(38, 40, 50);
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 126F));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            Controls.Add(layout);

            statusLabel = new Label();
            statusLabel.Dock = DockStyle.Fill;
            statusLabel.Height = 28;
            statusLabel.Padding = new Padding(20, 6, 0, 0);
            statusLabel.ForeColor = Color.FromArgb(148, 151, 162);
            statusLabel.BackColor = Color.FromArgb(38, 40, 50);
            statusLabel.Font = new Font("Microsoft YaHei UI", 8F);
            statusLabel.Text = "数据保存在 " + DataPath;
            layout.Controls.Add(statusLabel, 0, 2);

            var topArea = new Panel();
            topArea.Dock = DockStyle.Fill;
            topArea.Height = 126;
            topArea.BackColor = Color.FromArgb(58, 60, 72);
            layout.Controls.Add(topArea, 0, 0);

            var header = new Panel();
            header.Dock = DockStyle.Top;
            header.Height = 78;
            header.Padding = new Padding(20, 14, 18, 10);
            header.BackColor = Color.FromArgb(58, 60, 72);
            topArea.Controls.Add(header);

            titleLabel = new Label();
            titleLabel.Text = "Sessions";
            titleLabel.AutoSize = true;
            titleLabel.ForeColor = Color.White;
            titleLabel.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            titleLabel.Location = new Point(20, 17);
            header.Controls.Add(titleLabel);

            var topButtons = new FlowLayoutPanel();
            topButtons.FlowDirection = FlowDirection.RightToLeft;
            topButtons.Dock = DockStyle.Right;
            topButtons.Width = 178;
            topButtons.BackColor = header.BackColor;
            header.Controls.Add(topButtons);
            AddRoundButton(topButtons, "x", "退出", 42, delegate { ExitApp(); });
            AddRoundButton(topButtons, "▣", "开机常驻", 42, delegate { InstallStartup(); });
            AddRoundButton(topButtons, "↻", "扫描", 42, delegate { ScanNow(); RefreshAll(); });

            subtitleLabel = new Label();
            subtitleLabel.Dock = DockStyle.Fill;
            subtitleLabel.Height = 48;
            subtitleLabel.Padding = new Padding(20, 8, 18, 0);
            subtitleLabel.ForeColor = Color.FromArgb(178, 181, 192);
            subtitleLabel.BackColor = Color.FromArgb(54, 56, 67);
            subtitleLabel.Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Bold);
            topArea.Controls.Add(subtitleLabel);

            sessionFeed = new FlowLayoutPanel();
            sessionFeed.Dock = DockStyle.Fill;
            sessionFeed.AutoScroll = true;
            sessionFeed.WrapContents = false;
            sessionFeed.FlowDirection = FlowDirection.TopDown;
            sessionFeed.Padding = new Padding(18, 14, 20, 16);
            sessionFeed.BackColor = Color.FromArgb(38, 40, 50);
            sessionFeed.Resize += delegate { RefreshSessions(); };
            layout.Controls.Add(sessionFeed, 0, 1);
        }

        private void BuildUi()
        {
            BackColor = Color.FromArgb(38, 40, 50);
            Padding = new Padding(1);

            var header = new Panel();
            header.Dock = DockStyle.Top;
            header.Height = 78;
            header.Padding = new Padding(20, 14, 18, 10);
            header.BackColor = Color.FromArgb(58, 60, 72);
            Controls.Add(header);

            titleLabel = new Label();
            titleLabel.Text = "Sessions";
            titleLabel.AutoSize = true;
            titleLabel.ForeColor = Color.White;
            titleLabel.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            titleLabel.Location = new Point(20, 17);
            header.Controls.Add(titleLabel);

            var topButtons = new FlowLayoutPanel();
            topButtons.FlowDirection = FlowDirection.RightToLeft;
            topButtons.Dock = DockStyle.Right;
            topButtons.Width = 230;
            topButtons.BackColor = header.BackColor;
            header.Controls.Add(topButtons);
            AddRoundButton(topButtons, "×", "退出", 42, delegate { ExitApp(); });
            AddRoundButton(topButtons, "▣", "开机常驻", 42, delegate { InstallStartup(); });
            AddRoundButton(topButtons, "↻", "扫描", 42, delegate { ScanNow(); RefreshAll(); });
            AddRoundButton(topButtons, "+", "添加", 42, delegate(object sender, EventArgs e) { ShowAddMenu((Control)sender); });

            subtitleLabel = new Label();
            subtitleLabel.Dock = DockStyle.Top;
            subtitleLabel.Height = 30;
            subtitleLabel.Padding = new Padding(20, 7, 0, 0);
            subtitleLabel.ForeColor = Color.FromArgb(178, 181, 192);
            subtitleLabel.BackColor = Color.FromArgb(54, 56, 67);
            subtitleLabel.Font = new Font("Microsoft YaHei UI", 9F);
            Controls.Add(subtitleLabel);

            statusLabel = new Label();
            statusLabel.Dock = DockStyle.Bottom;
            statusLabel.Height = 28;
            statusLabel.Padding = new Padding(20, 6, 0, 0);
            statusLabel.ForeColor = Color.FromArgb(148, 151, 162);
            statusLabel.BackColor = Color.FromArgb(38, 40, 50);
            statusLabel.Font = new Font("Microsoft YaHei UI", 8F);
            statusLabel.Text = "数据保存在 " + DataPath;
            Controls.Add(statusLabel);

            sessionFeed = new FlowLayoutPanel();
            sessionFeed.Dock = DockStyle.Fill;
            sessionFeed.AutoScroll = true;
            sessionFeed.WrapContents = false;
            sessionFeed.FlowDirection = FlowDirection.TopDown;
            sessionFeed.Padding = new Padding(18, 16, 20, 16);
            sessionFeed.BackColor = Color.FromArgb(38, 40, 50);
            sessionFeed.Resize += delegate { RefreshSessions(); };
            Controls.Add(sessionFeed);

            header.BringToFront();
            subtitleLabel.BringToFront();
            statusLabel.BringToFront();
        }

        private Button AddRoundButton(Control parent, string text, string tip, int size, EventHandler click)
        {
            var button = new Button();
            button.Text = text;
            button.Width = size;
            button.Height = size;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = Color.FromArgb(66, 68, 82);
            button.ForeColor = Color.FromArgb(235, 236, 241);
            button.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            button.Margin = new Padding(5, 4, 0, 0);
            button.Click += click;
            new ToolTip().SetToolTip(button, tip);
            parent.Controls.Add(button);
            return button;
        }

        private void ShowAddMenu(Control anchor)
        {
            var menu = CreateGlassMenu();
            menu.Items.Add("新建项目", null, delegate { NewProject(); });
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("添加网站地址", null, delegate { AddResourceFromTop("website"); });
            menu.Items.Add("添加普通链接", null, delegate { AddResourceFromTop("link"); });
            menu.Items.Add("添加文件/文件夹路径", null, delegate { AddResourceFromTop("path"); });
            menu.Items.Add("添加文字备注", null, delegate { AddResourceFromTop("note"); });
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("添加 AI 会话文件夹", null, delegate { AddCustomScanFolder(); });
            menu.Show(anchor, new Point(-170, anchor.Height + 4));
        }

        private ContextMenuStrip CreateGlassMenu()
        {
            var menu = new ContextMenuStrip();
            menu.BackColor = Color.FromArgb(30, 32, 42);
            menu.ForeColor = Color.White;
            menu.ShowImageMargin = false;
            menu.Font = new Font("Microsoft YaHei UI", 10F);
            menu.Padding = new Padding(8, 8, 8, 8);
            return menu;
        }

        private Button AddButton(Control parent, string text, int width, EventHandler click)
        {
            return AddButton(parent, text, width, click, false);
        }

        private Button AddButton(Control parent, string text, int width, EventHandler click, bool primary)
        {
            var button = new Button();
            button.Text = text;
            button.Width = width;
            button.Height = 30;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = primary ? accent : Color.FromArgb(232, 234, 238);
            button.ForeColor = primary ? Color.White : textMain;
            button.Font = new Font("Microsoft YaHei UI", 9F);
            button.Margin = new Padding(0, 0, 8, 8);
            button.Click += click;
            parent.Controls.Add(button);
            return button;
        }

        private void BuildTray()
        {
            var menu = new ContextMenuStrip();
            menu.Items.Add("打开 Pickup", null, delegate { ShowMainWindow(); });
            menu.Items.Add("立即扫描", null, delegate { ScanNow(); RefreshAll(); });
            menu.Items.Add("设为开机常驻", null, delegate { InstallStartup(); });
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("退出", null, delegate { ExitApp(); });

            tray = new NotifyIcon();
            tray.Text = "Pickup";
            tray.Icon = SystemIcons.Application;
            tray.Visible = true;
            tray.ContextMenuStrip = menu;
            tray.DoubleClick += delegate { ShowMainWindow(); };
        }

        private void BuildForegroundTracker()
        {
            foregroundTimer = new Timer();
            foregroundTimer.Interval = 2500;
            foregroundTimer.Tick += delegate { TrackForegroundAiWindow(); };
            foregroundTimer.Start();

            scanTimer = new Timer();
            scanTimer.Interval = 30000;
            scanTimer.Tick += delegate { ScanNow(); };
            scanTimer.Start();
        }

        private void ShowMainWindow()
        {
            Show();
            WindowState = FormWindowState.Normal;
            Activate();
        }

        private void ExitApp()
        {
            allowExit = true;
            tray.Visible = false;
            SaveState();
            Close();
        }

        private void LoadState()
        {
            Directory.CreateDirectory(dataDir);
            if (!File.Exists(DataPath))
            {
                state = new AppState();
                return;
            }
            try
            {
                var serializer = new XmlSerializer(typeof(AppState));
                using (var stream = File.OpenRead(DataPath))
                    state = (AppState)serializer.Deserialize(stream);
                if (state.Projects == null) state.Projects = new List<ProjectItem>();
                if (state.Sessions == null) state.Sessions = new List<SessionItem>();
                if (state.CustomScanFolders == null) state.CustomScanFolders = new List<string>();
                foreach (var session in state.Sessions)
                    if (session.Resources == null) session.Resources = new List<SessionResource>();
            }
            catch
            {
                state = new AppState();
            }
        }

        private void SaveState()
        {
            Directory.CreateDirectory(dataDir);
            var serializer = new XmlSerializer(typeof(AppState));
            using (var stream = File.Create(DataPath))
                serializer.Serialize(stream, state);
        }

        private void SetStatus(string text)
        {
            try
            {
                if (statusLabel != null) statusLabel.Text = text ?? "";
            }
            catch { }
        }

        private string ExtractProjectKeyFromWindowTitle(string title)
        {
            string text = (title ?? "").Trim();
            if (string.IsNullOrWhiteSpace(text)) return "未命名 session";

            string[] separators = new[] { " - ", " — ", " – ", " | ", " · ", " - Google Chrome", " - Microsoft Edge" };
            foreach (var sep in separators)
            {
                int index = text.IndexOf(sep, StringComparison.OrdinalIgnoreCase);
                if (index > 0)
                {
                    string left = text.Substring(0, index).Trim();
                    if (left.Length >= 2) text = left;
                    break;
                }
            }

            text = Regex.Replace(text, @"\s+", " ").Trim();
            if (text.Length > 72) text = text.Substring(0, 72) + "...";
            return string.IsNullOrWhiteSpace(text) ? "AI session" : text;
        }

        private void TrackForegroundAiWindow()
        {
            try
            {
                IntPtr hwnd = GetForegroundWindow();
                if (hwnd == IntPtr.Zero) return;

                var text = new StringBuilder(512);
                GetWindowText(hwnd, text, text.Capacity);
                string title = (text.ToString() ?? "").Trim();
                if (string.IsNullOrWhiteSpace(title)) return;

                uint pid;
                GetWindowThreadProcessId(hwnd, out pid);
                if (pid == 0) return;

                string processName = "";
                string exePath = "";
                try
                {
                    var process = Process.GetProcessById((int)pid);
                    processName = process.ProcessName ?? "";
                    try { exePath = process.MainModule == null ? "" : process.MainModule.FileName; }
                    catch { exePath = ""; }
                }
                catch { return; }

                string host = KnownAiHostName(processName + " " + title + " " + exePath);
                string evidence = processName + " " + title + " " + exePath;
                if (string.Equals(processName, Process.GetCurrentProcess().ProcessName, StringComparison.OrdinalIgnoreCase)) return;
                if (host == "AI" && !LooksLikeAiText(evidence))
                {
                    if ((DateTime.UtcNow - lastWindowSeenUtc).TotalMinutes > 2)
                    {
                        activeWindowFingerprint = null;
                        activeWindowSessionId = null;
                    }
                    return;
                }

                string projectKey = ExtractProjectKeyFromWindowTitle(title);
                string key = host + "|" + processName + "|" + projectKey;
                bool sameActivity = key == activeWindowFingerprint &&
                    !string.IsNullOrWhiteSpace(activeWindowSessionId) &&
                    (DateTime.UtcNow - lastWindowSeenUtc).TotalMinutes < 20;
                lastForegroundKey = key;

                string id = sameActivity
                    ? activeWindowSessionId
                    : "windowseg:" + StableId(key + "|" + DateTimeOffset.UtcNow.ToString("yyyyMMddHHmmss"));
                var existing = state.Sessions.FirstOrDefault(s => s.Id == id);
                if (existing == null)
                {
                    state.Sessions.Add(new SessionItem
                    {
                        Id = id,
                        Source = "window_ai",
                        Host = host,
                        Title = projectKey,
                        Cwd = "",
                        LastActive = DateTimeOffset.UtcNow.ToString("o"),
                        LastMessage = "正在使用 " + host + "：" + title,
                        RawPath = exePath,
                        Hidden = false,
                        Resources = new List<SessionResource>()
                    });
                }
                else
                {
                    existing.Host = host;
                    existing.Title = projectKey;
                    existing.LastActive = DateTimeOffset.UtcNow.ToString("o");
                    existing.LastMessage = "正在使用 " + host + "：" + title;
                    existing.RawPath = exePath;
                    if (existing.Resources == null) existing.Resources = new List<SessionResource>();
                }

                activeWindowFingerprint = key;
                activeWindowSessionId = id;
                lastWindowSeenUtc = DateTime.UtcNow;
                AddAutomationSessions(hwnd, host, processName);
                SaveState();
                RefreshAll();
                SetStatus("持续记录：" + host + " · " + OneLine(projectKey));
            }
            catch
            {
                SetStatus("前台窗口记录暂时跳过了一次。");
            }
        }

        private void AddAutomationSessions(IntPtr hwnd, string host, string processName)
        {
            try
            {
                var root = AutomationElement.FromHandle(hwnd);
                if (root == null) return;
                var all = root.FindAll(TreeScope.Descendants, Condition.TrueCondition);
                var titles = new List<string>();
                int limit = Math.Min(all.Count, 350);
                for (int i = 0; i < limit; i++)
                {
                    string name = "";
                    try { name = all[i].Current.Name; }
                    catch { continue; }
                    name = NormalizeAutomationTitle(name);
                    if (LooksLikeSessionTitle(name) && !titles.Any(t => string.Equals(t, name, StringComparison.OrdinalIgnoreCase)))
                        titles.Add(name);
                    if (titles.Count >= 20) break;
                }

                foreach (var title in titles)
                {
                    string id = "uia:" + StableId(host + "|" + processName + "|" + title);
                    var existing = state.Sessions.FirstOrDefault(s => s.Id == id);
                    if (existing == null)
                    {
                        state.Sessions.Add(new SessionItem
                        {
                            Id = id,
                            Source = "window_uia",
                            Host = host,
                            Title = title,
                            Cwd = "",
                            LastActive = DateTimeOffset.UtcNow.ToString("o"),
                            LastMessage = "从 " + host + " 窗口侧边栏识别到的会话标题",
                            RawPath = "",
                            Hidden = false,
                            Resources = new List<SessionResource>()
                        });
                    }
                    else
                    {
                        existing.LastActive = DateTimeOffset.UtcNow.ToString("o");
                        existing.LastMessage = "从 " + host + " 窗口侧边栏识别到的会话标题";
                        if (existing.Resources == null) existing.Resources = new List<SessionResource>();
                    }
                }
            }
            catch
            {
            }
        }

        private string NormalizeAutomationTitle(string value)
        {
            string text = (value ?? "").Replace("\r", " ").Replace("\n", " ").Trim();
            text = Regex.Replace(text, @"\s+", " ");
            if (text.Length > 96) text = text.Substring(0, 96);
            return text;
        }

        private bool LooksLikeSessionTitle(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return false;
            if (text.Length < 4 || text.Length > 96) return false;
            string lower = text.ToLowerInvariant();
            string[] noise = new[]
            {
                "发送", "复制", "关闭", "设置", "新建", "搜索", "登录", "注册", "菜单", "更多", "最小化", "最大化",
                "send", "copy", "close", "settings", "search", "menu", "new chat", "history", "upgrade",
                "ctrl", "shift", "enter", "esc", "tab"
            };
            foreach (var n in noise)
                if (lower == n || lower.Contains(n) || lower.Contains("button") || lower.Contains("按钮")) return false;
            if (text.Count(char.IsLetterOrDigit) < 2 && !Regex.IsMatch(text, @"[\u4e00-\u9fff]{2,}")) return false;
            return true;
        }

        private void RefreshAll()
        {
            RefreshSessions();
        }

        private void RefreshSessions()
        {
            if (sessionFeed == null) return;
            sessionFeed.SuspendLayout();
            sessionFeed.Controls.Clear();

            int totalVisible = state.Sessions.Count(s => !s.Hidden);
            int unassignedCount = state.Sessions.Count(s => !s.Hidden && string.IsNullOrEmpty(s.LinkedProjectId));
            subtitleLabel.Text = "共 " + totalVisible + " 条会话，" + unassignedCount + " 条未分配。右侧 ... 可整理会话。";

            foreach (var project in ActiveProjects())
            {
                var sessions = state.Sessions
                    .Where(s => !s.Hidden && s.LinkedProjectId == project.Id)
                    .OrderByDescending(s => s.LastActive ?? "")
                    .ToList();
                AddProjectSection(project, sessions);
            }

            var unassigned = state.Sessions
                .Where(s => !s.Hidden && string.IsNullOrEmpty(s.LinkedProjectId))
                .OrderByDescending(s => s.LastActive ?? "")
                .ToList();
            AddProjectSection(null, unassigned);

            if (totalVisible == 0)
            {
                AddEmptyState();
            }

            sessionFeed.ResumeLayout();
        }

        private int FeedWidth()
        {
            if (sessionFeed == null) return 390;
            int width = sessionFeed.ClientSize.Width - 46;
            return Math.Max(400, width);
        }

        private void AddProjectSection(ProjectItem project, List<SessionItem> sessions)
        {
            var header = new Panel();
            header.Width = FeedWidth();
            header.Height = project == null ? 66 : 78;
            header.Margin = new Padding(0, 0, 0, 4);
            header.BackColor = Color.FromArgb(48, 50, 60);

            var name = new Label();
            name.AutoSize = false;
            name.Left = 0;
            name.Top = 10;
            name.Width = header.Width - 64;
            name.Height = 28;
            name.ForeColor = Color.FromArgb(244, 245, 249);
            name.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            name.Text = project == null ? "其他 session (" + sessions.Count + ")" : project.Name;
            header.Controls.Add(name);

            var desc = new Label();
            desc.AutoSize = false;
            desc.Left = 0;
            desc.Top = 40;
            desc.Width = header.Width - 42;
            desc.Height = 28;
            desc.ForeColor = Color.FromArgb(151, 154, 166);
            desc.Font = new Font("Microsoft YaHei UI", 9F);
            desc.Text = project == null
                ? "点每条 session 右侧 ... 添加网站、链接、路径或备注"
                : (string.IsNullOrWhiteSpace(project.Description) ? "添加概述..." : project.Description);
            header.Controls.Add(desc);

            var menuButton = new Button();
            menuButton.Text = "...";
            menuButton.Width = 38;
            menuButton.Height = 30;
            menuButton.Left = header.Width - 42;
            menuButton.Top = 12;
            menuButton.FlatStyle = FlatStyle.Flat;
            menuButton.FlatAppearance.BorderSize = 0;
            menuButton.BackColor = Color.FromArgb(48, 50, 60);
            menuButton.ForeColor = Color.FromArgb(220, 222, 230);
            menuButton.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            new ToolTip().SetToolTip(menuButton, project == null ? "其他 session 菜单：新建/添加内容" : "项目菜单：新建/添加/编辑/归档");
            if (project == null)
                menuButton.Click += delegate { ShowGeneralProjectMenu(menuButton); };
            else
                menuButton.Click += delegate { ShowProjectMenu(project, menuButton); };
            header.Controls.Add(menuButton);

            sessionFeed.Controls.Add(header);

            if (sessions.Count == 0 && project != null)
            {
                AddHintRow("这个项目还没有 session。可以从“其他 session”里通过 ... 添加进来。");
            }
            foreach (var session in sessions)
                AddSessionRow(session, project);
        }

        private void AddHintRow(string text)
        {
            var label = new Label();
            label.Width = FeedWidth();
            label.Height = 34;
            label.Margin = new Padding(0, 0, 0, 10);
            label.ForeColor = Color.FromArgb(135, 138, 150);
            label.BackColor = Color.FromArgb(48, 50, 60);
            label.Font = new Font("Microsoft YaHei UI", 9F);
            label.Text = text;
            sessionFeed.Controls.Add(label);
        }

        private void AddEmptyState()
        {
            var label = new Label();
            label.Width = FeedWidth();
            label.Height = 120;
            label.Margin = new Padding(0, 30, 0, 0);
            label.ForeColor = Color.FromArgb(190, 193, 202);
            label.BackColor = Color.FromArgb(48, 50, 60);
            label.Font = new Font("Microsoft YaHei UI", 11F);
            label.TextAlign = ContentAlignment.MiddleCenter;
            label.Text = "还没有扫描到 session\n点击右上角 ↻ 重新扫描";
            sessionFeed.Controls.Add(label);
        }

        private void AddSessionRow(SessionItem session, ProjectItem currentProject)
        {
            if (session.Resources == null) session.Resources = new List<SessionResource>();
            int resourceCount = session.Resources.Count;
            var row = new Panel();
            row.Width = FeedWidth();
            row.Height = 96 + Math.Min(resourceCount, 4) * 30 + (resourceCount > 4 ? 22 : 0);
            row.Margin = new Padding(0, 0, 0, 8);
            row.BackColor = Color.FromArgb(62, 64, 76);
            row.Cursor = Cursors.Hand;
            row.DoubleClick += delegate { OpenSession(session); };

            var icon = new Label();
            icon.Left = 0;
            icon.Top = 24;
            icon.Width = 42;
            icon.Height = 34;
            icon.TextAlign = ContentAlignment.MiddleCenter;
            icon.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            icon.Text = SourceMark(session);
            icon.ForeColor = SourceColor(session);
            row.Controls.Add(icon);

            var title = new Label();
            title.Left = 46;
            title.Top = 12;
            title.Width = row.Width - 112;
            title.Height = 24;
            title.ForeColor = Color.FromArgb(246, 247, 251);
            title.Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Bold);
            title.Text = OneLine(session.DisplayTitle);
            title.DoubleClick += delegate { OpenSession(session); };
            row.Controls.Add(title);

            var preview = new Label();
            preview.Left = 46;
            preview.Top = 40;
            preview.Width = row.Width - 112;
            preview.Height = 24;
            preview.ForeColor = Color.FromArgb(206, 209, 218);
            preview.Font = new Font("Microsoft YaHei UI", 9F);
            preview.Text = OneLine(session.LastMessage);
            row.Controls.Add(preview);

            var meta = new Label();
            meta.Left = 46;
            meta.Top = 67;
            meta.Width = row.Width - 112;
            meta.Height = 20;
            meta.ForeColor = Color.FromArgb(156, 160, 174);
            meta.Font = new Font("Microsoft YaHei UI", 8.5F, FontStyle.Bold);
            meta.Text = (session.Host ?? session.Source ?? "Session") + " · " + AgeText(session.LastActive);
            row.Controls.Add(meta);

            var menuButton = new Button();
            menuButton.Text = "...";
            menuButton.Width = 38;
            menuButton.Height = 34;
            menuButton.Left = row.Width - 46;
            menuButton.Top = 30;
            menuButton.FlatStyle = FlatStyle.Flat;
            menuButton.FlatAppearance.BorderSize = 0;
            menuButton.BackColor = row.BackColor;
            menuButton.ForeColor = Color.FromArgb(232, 234, 240);
            menuButton.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            menuButton.Click += delegate { ShowSessionMenu(session, currentProject, menuButton); };
            row.Controls.Add(menuButton);

            int top = 94;
            int shown = 0;
            foreach (var resource in session.Resources)
            {
                if (shown >= 4) break;
                var chip = new Label();
                chip.Left = 46;
                chip.Top = top;
                chip.Width = row.Width - 112;
                chip.Height = 24;
                chip.Padding = new Padding(10, 2, 10, 2);
                chip.BackColor = Color.FromArgb(74, 77, 90);
                chip.ForeColor = ResourceColor(resource.Kind);
                chip.Font = new Font("Microsoft YaHei UI", 8.5F, FontStyle.Bold);
                chip.Text = ResourceText(resource);
                chip.Cursor = Cursors.Hand;
                chip.DoubleClick += delegate { OpenResource(resource); };
                chip.Click += delegate { OpenResource(resource); };
                row.Controls.Add(chip);
                top += 30;
                shown++;
            }
            if (resourceCount > 4)
            {
                var more = new Label();
                more.Left = 46;
                more.Top = top - 2;
                more.Width = row.Width - 112;
                more.Height = 20;
                more.ForeColor = Color.FromArgb(168, 172, 184);
                more.Font = new Font("Microsoft YaHei UI", 8F);
                more.Text = "还有 " + (resourceCount - 4) + " 条补充内容，右侧 ... 管理";
                row.Controls.Add(more);
            }

            sessionFeed.Controls.Add(row);
        }

        private List<ProjectItem> ActiveProjects()
        {
            return state.Projects.Where(p => p.Status == "active").OrderBy(p => p.SortOrder).ThenBy(p => p.Name).ToList();
        }

        private List<ProjectItem> ArchivedProjects()
        {
            return state.Projects.Where(p => p.Status == "archived").OrderBy(p => p.Name).ToList();
        }

        private ProjectItem SelectedProject()
        {
            var list = ActiveProjects();
            if (projectList == null || projectList.SelectedIndex < 0 || projectList.SelectedIndex >= list.Count) return null;
            return list[projectList.SelectedIndex];
        }

        private ProjectItem SelectedArchivedProject()
        {
            var list = ArchivedProjects();
            if (archivedList.SelectedIndex < 0 || archivedList.SelectedIndex >= list.Count) return null;
            return list[archivedList.SelectedIndex];
        }

        private SessionItem SelectedSession()
        {
            if (sessionList.SelectedItems.Count == 0) return null;
            string id = Convert.ToString(sessionList.SelectedItems[0].Tag);
            return state.Sessions.FirstOrDefault(s => s.Id == id);
        }

        private void NewProject()
        {
            string name = Prompt.Show("项目名称：", "新建项目", "");
            if (string.IsNullOrWhiteSpace(name)) return;
            state.Projects.Add(new ProjectItem
            {
                Id = Guid.NewGuid().ToString("N"),
                Name = name.Trim(),
                Description = "",
                Status = "active",
                SortOrder = 0
            });
            NormalizeProjectOrder();
            SaveState();
            RefreshAll();
        }

        private void RenameProject()
        {
            var project = SelectedProject();
            if (project == null) return;
            string name = Prompt.Show("项目名称：", "重命名项目", project.Name);
            if (string.IsNullOrWhiteSpace(name)) return;
            project.Name = name.Trim();
            SaveState();
            RefreshAll();
        }

        private void ArchiveProject()
        {
            var project = SelectedProject();
            if (project == null) return;
            project.Status = "archived";
            SaveState();
            RefreshAll();
        }

        private void RestoreProject()
        {
            var project = SelectedArchivedProject();
            if (project == null) return;
            project.Status = "active";
            project.SortOrder = 0;
            NormalizeProjectOrder();
            SaveState();
            RefreshAll();
        }

        private void DeleteArchivedProject()
        {
            var project = SelectedArchivedProject();
            if (project == null) return;
            if (MessageBox.Show("确定删除这个归档项目吗？关联的会话会回到未分配列表。", "Pickup", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
            state.Projects.Remove(project);
            foreach (var session in state.Sessions.Where(s => s.LinkedProjectId == project.Id))
                session.LinkedProjectId = null;
            SaveState();
            RefreshAll();
        }

        private void MoveProject(int delta)
        {
            var project = SelectedProject();
            if (project == null) return;
            project.SortOrder += delta;
            NormalizeProjectOrder();
            SaveState();
            RefreshAll();
        }

        private void NormalizeProjectOrder()
        {
            int order = 0;
            foreach (var project in ActiveProjects())
            {
                project.SortOrder = order;
                order += 1000;
            }
        }

        private void AssignSelectedSession()
        {
            var project = SelectedProject();
            var session = SelectedSession();
            if (project == null || session == null) return;
            session.LinkedProjectId = project.Id;
            SaveState();
            RefreshAll();
        }

        private void UnassignSelectedSession()
        {
            var session = SelectedSession();
            if (session == null) return;
            session.LinkedProjectId = null;
            SaveState();
            RefreshAll();
        }

        private void RenameSelectedSession()
        {
            var session = SelectedSession();
            if (session == null) return;
            string title = Prompt.Show("Session title:", "Rename session", session.DisplayTitle);
            if (string.IsNullOrWhiteSpace(title)) return;
            session.TitleOverride = title.Trim();
            SaveState();
            RefreshAll();
        }

        private void HideSelectedSession()
        {
            var session = SelectedSession();
            if (session == null) return;
            session.Hidden = true;
            SaveState();
            RefreshAll();
        }

        private void ShowProjectMenu(ProjectItem project, Control anchor)
        {
            var menu = CreateGlassMenu();
            menu.Items.Add("新建项目", null, delegate { NewProject(); });
            menu.Items.Add("添加网站", null, delegate { AddResourceToProject(project, "website"); });
            menu.Items.Add("添加链接", null, delegate { AddResourceToProject(project, "link"); });
            menu.Items.Add("添加路径", null, delegate { AddResourceToProject(project, "path"); });
            menu.Items.Add("添加备注", null, delegate { AddResourceToProject(project, "note"); });
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("↑ 上移", null, delegate { project.SortOrder -= 1500; NormalizeProjectOrder(); SaveState(); RefreshAll(); });
            menu.Items.Add("↓ 下移", null, delegate { project.SortOrder += 1500; NormalizeProjectOrder(); SaveState(); RefreshAll(); });
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("编辑名称", null, delegate { RenameProject(project); });
            menu.Items.Add("编辑概述", null, delegate { EditProjectDescription(project); });
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("归档项目", null, delegate { project.Status = "archived"; SaveState(); RefreshAll(); });
            menu.Items.Add("删除项目", null, delegate { DeleteProject(project); });
            menu.Show(anchor, new Point(-160, anchor.Height + 2));
        }

        private void ShowGeneralProjectMenu(Control anchor)
        {
            var menu = CreateGlassMenu();
            menu.Items.Add("新建项目", null, delegate { NewProject(); });
            menu.Items.Add("添加网站", null, delegate { AddResourceFromTop("website"); });
            menu.Items.Add("添加链接", null, delegate { AddResourceFromTop("link"); });
            menu.Items.Add("添加路径", null, delegate { AddResourceFromTop("path"); });
            menu.Items.Add("添加备注", null, delegate { AddResourceFromTop("note"); });
            menu.Show(anchor, new Point(-160, anchor.Height + 2));
        }

        private void ShowSessionMenu(SessionItem session, ProjectItem currentProject, Control anchor)
        {
            var menu = CreateGlassMenu();
            menu.Items.Add("新建项目", null, delegate { NewProject(); });
            menu.Items.Add("添加网站", null, delegate { AddResourceToSession(session, "website"); });
            menu.Items.Add("添加链接", null, delegate { AddResourceToSession(session, "link"); });
            menu.Items.Add("添加路径", null, delegate { AddResourceToSession(session, "path"); });
            menu.Items.Add("添加备注", null, delegate { AddResourceToSession(session, "note"); });
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("打开", null, delegate { OpenSession(session); });
            menu.Items.Add("重命名", null, delegate { RenameSession(session); });
            if (session.Resources != null && session.Resources.Count > 0)
            {
                var resources = new ToolStripMenuItem("查看补充内容");
                foreach (var resource in session.Resources)
                {
                    var r = resource;
                    resources.DropDownItems.Add(ResourceText(r), null, delegate { OpenResource(r); });
                }
                menu.Items.Add(resources);
            }

            var assign = new ToolStripMenuItem("添加到项目");
            foreach (var project in ActiveProjects())
            {
                var p = project;
                assign.DropDownItems.Add(p.Name, null, delegate
                {
                    session.LinkedProjectId = p.Id;
                    SaveState();
                    RefreshAll();
                });
            }
            menu.Items.Add(assign);

            if (currentProject != null)
                menu.Items.Add("移出项目", null, delegate { session.LinkedProjectId = null; SaveState(); RefreshAll(); });

            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("隐藏 session", null, delegate { session.Hidden = true; SaveState(); RefreshAll(); });
            if (session.Source == "link")
                menu.Items.Add("删除链接", null, delegate { state.Sessions.Remove(session); SaveState(); RefreshAll(); });
            menu.Show(anchor, new Point(-150, anchor.Height + 2));
        }

        private void RenameProject(ProjectItem project)
        {
            string name = Prompt.Show("项目名称：", "编辑名称", project.Name);
            if (string.IsNullOrWhiteSpace(name)) return;
            project.Name = name.Trim();
            SaveState();
            RefreshAll();
        }

        private void EditProjectDescription(ProjectItem project)
        {
            string desc = Prompt.Show("项目概述：", "编辑概述", project.Description ?? "");
            if (desc == null) return;
            project.Description = desc.Trim();
            SaveState();
            RefreshAll();
        }

        private void DeleteProject(ProjectItem project)
        {
            if (MessageBox.Show("确定删除这个项目吗？关联的会话会回到“其他 session”。", "Pickup", MessageBoxButtons.YesNo) != DialogResult.Yes)
                return;
            state.Projects.Remove(project);
            foreach (var session in state.Sessions.Where(s => s.LinkedProjectId == project.Id))
                session.LinkedProjectId = null;
            SaveState();
            RefreshAll();
        }

        private void RenameSession(SessionItem session)
        {
            string title = Prompt.Show("Session 名称：", "重命名 session", session.DisplayTitle);
            if (string.IsNullOrWhiteSpace(title)) return;
            session.TitleOverride = title.Trim();
            SaveState();
            RefreshAll();
        }

        private void AddResourceToProject(ProjectItem project, string kind)
        {
            string titlePrompt = kind == "note" ? "备注标题：" : "名称：";
            string valuePrompt = "内容：";
            string caption = "添加内容";
            if (kind == "website") { valuePrompt = "网站地址："; caption = "添加网站"; }
            if (kind == "link") { valuePrompt = "链接地址："; caption = "添加链接"; }
            if (kind == "path") { valuePrompt = "文件或文件夹路径："; caption = "添加路径"; }
            if (kind == "note") { valuePrompt = "备注内容："; caption = "添加备注"; }

            string title = Prompt.Show(titlePrompt, caption, "");
            if (string.IsNullOrWhiteSpace(title)) return;
            string value = Prompt.Show(valuePrompt, caption, "");
            if (string.IsNullOrWhiteSpace(value)) return;
            string source = kind == "note" ? "note" : "link";
            string host = kind == "website" ? "Website" : kind == "path" ? "Path" : kind == "note" ? "Note" : "Link";
            if ((kind == "website" || kind == "link") &&
                !value.StartsWith("http://", StringComparison.OrdinalIgnoreCase) &&
                !value.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
                value = "https://" + value;
            state.Sessions.Add(new SessionItem
            {
                Id = source + ":" + Guid.NewGuid().ToString("N"),
                Source = source,
                Host = host,
                Title = title.Trim(),
                LastActive = DateTimeOffset.UtcNow.ToString("o"),
                LastMessage = value,
                RawPath = kind == "note" ? "" : value,
                LinkedProjectId = project.Id,
                Hidden = false
            });
            SaveState();
            RefreshAll();
        }

        private void AddResourceToSession(SessionItem session, string kind)
        {
            if (session == null) return;
            if (session.Resources == null) session.Resources = new List<SessionResource>();

            string titlePrompt = kind == "note" ? "备注标题：" : "名称：";
            string valuePrompt = "内容：";
            string caption = "添加内容到 session";
            if (kind == "website") { valuePrompt = "网站地址："; caption = "添加网站"; }
            if (kind == "link") { valuePrompt = "链接地址："; caption = "添加链接"; }
            if (kind == "path") { valuePrompt = "文件或文件夹路径："; caption = "添加路径"; }
            if (kind == "note") { valuePrompt = "备注内容："; caption = "添加备注"; }

            string title = Prompt.Show(titlePrompt, caption, "");
            if (string.IsNullOrWhiteSpace(title)) return;
            string value = Prompt.Show(valuePrompt, caption, "");
            if (string.IsNullOrWhiteSpace(value)) return;
            value = NormalizeResourceValue(kind, value);

            session.Resources.Add(new SessionResource
            {
                Id = Guid.NewGuid().ToString("N"),
                Kind = kind,
                Title = title.Trim(),
                Value = value,
                CreatedAt = DateTimeOffset.UtcNow.ToString("o")
            });
            SaveState();
            RefreshAll();
        }

        private void AddStandaloneResource(string kind)
        {
            string titlePrompt = kind == "note" ? "备注标题：" : "名称：";
            string valuePrompt = "内容：";
            string caption = "添加内容";
            if (kind == "website") { valuePrompt = "网站地址："; caption = "添加网站"; }
            if (kind == "link") { valuePrompt = "链接地址："; caption = "添加链接"; }
            if (kind == "path") { valuePrompt = "文件或文件夹路径："; caption = "添加路径"; }
            if (kind == "note") { valuePrompt = "备注内容："; caption = "添加备注"; }

            string title = Prompt.Show(titlePrompt, caption, "");
            if (string.IsNullOrWhiteSpace(title)) return;
            string value = Prompt.Show(valuePrompt, caption, "");
            if (string.IsNullOrWhiteSpace(value)) return;
            value = NormalizeResourceValue(kind, value);

            string source = kind == "note" ? "note" : "link";
            string host = kind == "website" ? "Website" : kind == "path" ? "Path" : kind == "note" ? "Note" : "Link";
            state.Sessions.Add(new SessionItem
            {
                Id = source + ":" + Guid.NewGuid().ToString("N"),
                Source = source,
                Host = host,
                Title = title.Trim(),
                LastActive = DateTimeOffset.UtcNow.ToString("o"),
                LastMessage = value,
                RawPath = kind == "note" ? "" : value,
                Hidden = false,
                Resources = new List<SessionResource>()
            });
            SaveState();
            RefreshAll();
        }

        private void AddResourceFromTop(string kind)
        {
            AddStandaloneResource(kind);
        }

        private void AddCustomScanFolder()
        {
            using (var dialog = new FolderBrowserDialog())
            {
                dialog.Description = "选择其他 AI 工具的会话/记录文件夹";
                dialog.ShowNewFolderButton = false;
                if (dialog.ShowDialog() != DialogResult.OK) return;
                if (state.CustomScanFolders == null) state.CustomScanFolders = new List<string>();
                if (!state.CustomScanFolders.Any(p => string.Equals(p, dialog.SelectedPath, StringComparison.OrdinalIgnoreCase)))
                    state.CustomScanFolders.Add(dialog.SelectedPath);
                SaveState();
                ScanNow();
                RefreshAll();
            }
        }

        private ProjectItem PickProjectForResource()
        {
            var projects = ActiveProjects();
            if (projects.Count == 0)
            {
                SetStatus("当前没有项目；内容会先作为独立 session 保存。");
                return null;
            }
            if (projects.Count == 1) return projects[0];

            string names = string.Join(" / ", projects.Select(p => p.Name).ToArray());
            string name = Prompt.Show("添加到哪个项目？可输入项目名：", "选择项目", projects[0].Name);
            if (string.IsNullOrWhiteSpace(name)) return null;
            var exact = projects.FirstOrDefault(p => string.Equals(p.Name, name.Trim(), StringComparison.OrdinalIgnoreCase));
            if (exact != null) return exact;
            var fuzzy = projects.FirstOrDefault(p => p.Name.IndexOf(name.Trim(), StringComparison.OrdinalIgnoreCase) >= 0);
            if (fuzzy != null) return fuzzy;
            MessageBox.Show("没有找到这个项目。当前项目：" + names, "Pickup");
            return null;
        }

        private string NormalizeResourceValue(string kind, string value)
        {
            value = (value ?? "").Trim();
            if ((kind == "website" || kind == "link") &&
                !value.StartsWith("http://", StringComparison.OrdinalIgnoreCase) &&
                !value.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
                value = "https://" + value;
            return value;
        }

        private string ResourceText(SessionResource resource)
        {
            if (resource == null) return "";
            string name = string.IsNullOrWhiteSpace(resource.Title) ? "未命名" : resource.Title.Trim();
            string value = string.IsNullOrWhiteSpace(resource.Value) ? "" : resource.Value.Trim();
            string prefix = "内容";
            if (resource.Kind == "website") prefix = "网站";
            if (resource.Kind == "link") prefix = "链接";
            if (resource.Kind == "path") prefix = "路径";
            if (resource.Kind == "note") prefix = "备注";
            string text = prefix + "：" + name;
            if (!string.IsNullOrWhiteSpace(value))
                text += " · " + value;
            return OneLine(text);
        }

        private Color ResourceColor(string kind)
        {
            if (kind == "website") return Color.FromArgb(119, 224, 177);
            if (kind == "link") return Color.FromArgb(126, 190, 255);
            if (kind == "path") return Color.FromArgb(235, 207, 132);
            if (kind == "note") return Color.FromArgb(230, 220, 255);
            return Color.FromArgb(220, 224, 232);
        }

        private void OpenResource(SessionResource resource)
        {
            if (resource == null) return;
            try
            {
                string value = resource.Value ?? "";
                if (resource.Kind == "note")
                {
                    MessageBox.Show(value, string.IsNullOrWhiteSpace(resource.Title) ? "备注" : resource.Title);
                    return;
                }
                if (resource.Kind == "path")
                {
                    if (SafeFileExists(value) || SafeDirectoryExists(value))
                    {
                        Process.Start(value);
                        return;
                    }
                    SetStatus("路径不存在或暂时无法打开：" + OneLine(value));
                    return;
                }
                if (resource.Kind == "website" || resource.Kind == "link")
                {
                    OpenExternal(value);
                    return;
                }
                MessageBox.Show(value, resource.Title ?? "补充内容");
            }
            catch (Exception ex)
            {
                SetStatus("打开失败：" + ex.Message);
            }
        }

        private bool SafeFileExists(string path)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(path)) return false;
                if (path.IndexOfAny(Path.GetInvalidPathChars()) >= 0) return false;
                return File.Exists(path);
            }
            catch
            {
                return false;
            }
        }

        private bool SafeDirectoryExists(string path)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(path)) return false;
                if (path.IndexOfAny(Path.GetInvalidPathChars()) >= 0) return false;
                return Directory.Exists(path);
            }
            catch
            {
                return false;
            }
        }

        private void OpenExternal(string target)
        {
            if (string.IsNullOrWhiteSpace(target))
                throw new InvalidOperationException("没有可打开的地址。");
            var psi = new ProcessStartInfo();
            psi.FileName = target.Trim();
            psi.UseShellExecute = true;
            Process.Start(psi);
        }

        private string OneLine(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return "";
            string clean = text.Replace("\r", " ").Replace("\n", " ").Trim();
            return clean.Length > 80 ? clean.Substring(0, 80) + "..." : clean;
        }

        private string SourceMark(SessionItem session)
        {
            string host = (session.Host ?? session.Source ?? "").ToLowerInvariant();
            if (host.Contains("claude")) return "✹";
            if (host.Contains("codex")) return "▣";
            if (host.Contains("豆包") || host.Contains("doubao")) return "豆";
            if (host.Contains("chatgpt")) return "G";
            if (host.Contains("cursor")) return "C";
            if (host.Contains("windsurf")) return "W";
            if (host.Contains("trae")) return "T";
            if (host.Contains("kimi")) return "K";
            if (host.Contains("deepseek")) return "D";
            if (host.Contains("link")) return "↗";
            if (host == "ai" || host.Contains("custom")) return "AI";
            return "●";
        }

        private Color SourceColor(SessionItem session)
        {
            string host = (session.Host ?? session.Source ?? "").ToLowerInvariant();
            if (host.Contains("claude")) return Color.FromArgb(255, 112, 72);
            if (host.Contains("codex")) return Color.FromArgb(91, 124, 255);
            if (host.Contains("豆包") || host.Contains("doubao")) return Color.FromArgb(255, 192, 82);
            if (host.Contains("chatgpt")) return Color.FromArgb(83, 221, 169);
            if (host.Contains("cursor")) return Color.FromArgb(230, 230, 238);
            if (host.Contains("windsurf")) return Color.FromArgb(80, 202, 255);
            if (host.Contains("trae")) return Color.FromArgb(181, 142, 255);
            if (host.Contains("kimi")) return Color.FromArgb(118, 164, 255);
            if (host.Contains("deepseek")) return Color.FromArgb(87, 200, 255);
            if (host.Contains("link")) return Color.FromArgb(91, 214, 160);
            if (host == "ai" || host.Contains("custom")) return Color.FromArgb(211, 149, 255);
            return Color.FromArgb(210, 213, 222);
        }

        private void OpenSession(SessionItem session)
        {
            if (session == null) return;
            try
            {
                if ((session.Source == "link" || session.Host == "Website") && !string.IsNullOrEmpty(session.RawPath))
                {
                    OpenExternal(session.RawPath);
                    return;
                }
                if (session.Source == "note")
                {
                    MessageBox.Show(session.LastMessage ?? "", session.DisplayTitle);
                    return;
                }
                if (session.Host == "Path" && !string.IsNullOrEmpty(session.RawPath))
                {
                    if (SafeFileExists(session.RawPath) || SafeDirectoryExists(session.RawPath))
                    {
                        Process.Start(session.RawPath);
                        return;
                    }
                }
                if (session.Source == "codex" && CommandExists("codex"))
                {
                    string sid = session.Id.Split(new[] { ':' }, 2)[1];
                    RunInPowerShell(ExistingDirOrHome(session.Cwd), "codex resume '" + sid.Replace("'", "''") + "'");
                    return;
                }
                if (session.Source == "claude_code" && CommandExists("claude"))
                {
                    string sid = session.Id.Split(new[] { ':' }, 2)[1];
                    RunInPowerShell(ExistingDirOrHome(session.Cwd), "claude --resume '" + sid.Replace("'", "''") + "'");
                    return;
                }
                if (!string.IsNullOrEmpty(session.RawPath) && SafeFileExists(session.RawPath))
                {
                    Process.Start(session.RawPath);
                    return;
                }
                if (!string.IsNullOrEmpty(session.Cwd) && SafeDirectoryExists(session.Cwd))
                {
                    Process.Start(session.Cwd);
                    return;
                }
                SetStatus("这条 session 没有可直接打开的路径。右侧 ... 可以添加网站、链接、路径或备注。");
            }
            catch (Exception ex)
            {
                SetStatus("打开失败：" + ex.Message);
            }
        }

        private void AddLink()
        {
            AddStandaloneResource("link");
        }

        private void OpenSelectedSession()
        {
            var session = SelectedSession();
            if (session == null) return;
            try
            {
                if (session.Source == "link" && !string.IsNullOrEmpty(session.RawPath))
                {
                    OpenExternal(session.RawPath);
                    return;
                }
                if (session.Source == "codex" && CommandExists("codex"))
                {
                    string sid = session.Id.Split(new[] { ':' }, 2)[1];
                    RunInPowerShell(ExistingDirOrHome(session.Cwd), "codex resume '" + sid.Replace("'", "''") + "'");
                    return;
                }
                if (session.Source == "claude_code" && CommandExists("claude"))
                {
                    string sid = session.Id.Split(new[] { ':' }, 2)[1];
                    RunInPowerShell(ExistingDirOrHome(session.Cwd), "claude --resume '" + sid.Replace("'", "''") + "'");
                    return;
                }
                if (!string.IsNullOrEmpty(session.RawPath) && SafeFileExists(session.RawPath))
                {
                    Process.Start(session.RawPath);
                    return;
                }
                if (!string.IsNullOrEmpty(session.Cwd) && SafeDirectoryExists(session.Cwd))
                {
                    Process.Start(session.Cwd);
                    return;
                }
                SetStatus("这条 session 没有可直接打开的路径。右侧 ... 可以添加网站、链接、路径或备注。");
            }
            catch (Exception ex)
            {
                SetStatus("打开失败：" + ex.Message);
            }
        }

        private string ExistingDirOrHome(string value)
        {
            if (!string.IsNullOrEmpty(value) && Directory.Exists(value)) return value;
            return Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        }

        private void RunInPowerShell(string cwd, string command)
        {
            var psi = new ProcessStartInfo("powershell.exe", "-NoExit -Command " + QuoteArgument(command));
            psi.WorkingDirectory = cwd;
            Process.Start(psi);
        }

        private string QuoteArgument(string value)
        {
            return "\"" + value.Replace("\"", "\\\"") + "\"";
        }

        private bool CommandExists(string command)
        {
            try
            {
                var psi = new ProcessStartInfo("where.exe", command);
                psi.CreateNoWindow = true;
                psi.UseShellExecute = false;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                var p = Process.Start(psi);
                p.WaitForExit(1200);
                return p.ExitCode == 0;
            }
            catch { return false; }
        }

        private void ScanNow()
        {
            TrackForegroundAiWindow();
            var found = new List<SessionItem>();
            var codex = ScanCodex().ToList();
            var claude = ScanClaude().ToList();
            var knownAi = ScanKnownAiAppFolders().ToList();
            var custom = ScanCustomAiFolders().ToList();
            found.AddRange(codex);
            found.AddRange(claude);
            found.AddRange(knownAi);
            found.AddRange(custom);
            var byId = state.Sessions.ToDictionary(s => s.Id, s => s);
            foreach (var item in found)
            {
                SessionItem existing;
                if (byId.TryGetValue(item.Id, out existing))
                {
                    existing.Source = item.Source;
                    existing.Host = item.Host;
                    existing.Title = item.Title;
                    existing.Cwd = item.Cwd;
                    existing.LastActive = item.LastActive;
                    existing.LastMessage = item.LastMessage;
                    existing.RawPath = item.RawPath;
                }
                else
                {
                    state.Sessions.Add(item);
                }
            }
            SaveState();
            statusLabel.Text = "已扫描 " + found.Count + " 条：Codex " + codex.Count + "，Claude " + claude.Count + "，其他AI " + knownAi.Count + "，自定义 " + custom.Count;
        }

        private IEnumerable<SessionItem> ScanCodex()
        {
            var result = new List<SessionItem>();
            if (!Directory.Exists(codexDir)) return result;
            foreach (var file in Directory.GetFiles(codexDir, "rollout-*.jsonl", SearchOption.AllDirectories))
            {
                var match = codexIdRegex.Match(Path.GetFileName(file));
                if (!match.Success) continue;
                string sid = match.Groups[1].Value;
                string cwd = null, firstUser = null, lastText = null, lastTime = null;
                foreach (var line in SafeReadLines(file))
                {
                    if (cwd == null && (line.Contains("\"session_meta\"") || line.Contains("\"turn_context\"")))
                        cwd = RegexValue(line, "\"cwd\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"");
                    if (!line.Contains("\"response_item\"") || !line.Contains("\"message\"")) continue;
                    string role = RegexValue(line, "\"role\"\\s*:\\s*\"([^\"]+)\"");
                    if (role != "user" && role != "assistant") continue;
                    string text = RegexValue(line, "\"text\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"");
                    if (role == "user" && firstUser == null && !string.IsNullOrEmpty(text) && !text.StartsWith("<environment_context>"))
                        firstUser = text;
                    if (!string.IsNullOrEmpty(text))
                    {
                        lastText = text;
                        lastTime = RegexValue(line, "\"timestamp\"\\s*:\\s*\"([^\"]+)\"");
                    }
                }
                if (string.IsNullOrEmpty(lastTime)) continue;
                string title = !string.IsNullOrEmpty(cwd) ? Path.GetFileName(cwd) : FirstLine(firstUser, 100);
                if (string.IsNullOrEmpty(title)) title = "Codex 会话";
                result.Add(new SessionItem
                {
                    Id = "codex:" + sid,
                    Source = "codex",
                    Host = "Codex",
                    Title = title,
                    Cwd = cwd,
                    LastActive = lastTime,
                    LastMessage = FirstLine(lastText, 200),
                    RawPath = file
                });
            }
            return result;
        }

        private IEnumerable<SessionItem> ScanClaude()
        {
            var result = new List<SessionItem>();
            if (!Directory.Exists(claudeDir)) return result;
            foreach (var file in Directory.GetFiles(claudeDir, "*.jsonl", SearchOption.AllDirectories))
            {
                string firstUser = null, lastText = null, lastTime = null, cwd = null, entry = null;
                foreach (var line in SafeReadLines(file))
                {
                    if (!line.Contains("\"type\":\"user\"") && !line.Contains("\"type\": \"user\"") &&
                        !line.Contains("\"type\":\"assistant\"") && !line.Contains("\"type\": \"assistant\""))
                        continue;
                    if (entry == null) entry = RegexValue(line, "\"entrypoint\"\\s*:\\s*\"([^\"]+)\"");
                    string type = RegexValue(line, "\"type\"\\s*:\\s*\"([^\"]+)\"");
                    string text = RegexValue(line, "\"text\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"");
                    if (type == "user" && firstUser == null && !string.IsNullOrEmpty(text)) firstUser = text;
                    if (!string.IsNullOrEmpty(text)) lastText = text;
                    string t = RegexValue(line, "\"timestamp\"\\s*:\\s*\"([^\"]+)\"");
                    if (!string.IsNullOrEmpty(t)) lastTime = t;
                    string c = RegexValue(line, "\"cwd\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"");
                    if (!string.IsNullOrEmpty(c)) cwd = c;
                }
                if (string.IsNullOrEmpty(lastTime)) continue;
                string sid = Path.GetFileNameWithoutExtension(file);
                string host = entry == "claude-desktop" ? "Claude" : "Claude Code";
                string title = FirstLine(firstUser, 100);
                if (string.IsNullOrEmpty(title) && !string.IsNullOrEmpty(cwd)) title = Path.GetFileName(cwd);
                if (string.IsNullOrEmpty(title)) title = host + " 会话";
                result.Add(new SessionItem
                {
                    Id = "claude:" + sid,
                    Source = "claude_code",
                    Host = host,
                    Title = title,
                    Cwd = cwd,
                    LastActive = lastTime,
                    LastMessage = FirstLine(lastText, 200),
                    RawPath = file
                });
            }
            return result;
        }

        private IEnumerable<SessionItem> ScanCustomAiFolders()
        {
            var result = new List<SessionItem>();
            if (state.CustomScanFolders == null) state.CustomScanFolders = new List<string>();
            var exts = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { ".jsonl", ".json", ".txt", ".md" };
            foreach (var folder in state.CustomScanFolders.Distinct().ToList())
            {
                if (string.IsNullOrWhiteSpace(folder) || !Directory.Exists(folder)) continue;
                IEnumerable<string> files;
                try
                {
                    files = Directory.GetFiles(folder, "*.*", SearchOption.AllDirectories)
                        .Where(f => exts.Contains(Path.GetExtension(f)));
                }
                catch
                {
                    continue;
                }
                foreach (var file in files.Take(500))
                {
                    string text = FirstReadableText(file);
                    if (string.IsNullOrWhiteSpace(text)) continue;
                    var info = new FileInfo(file);
                    result.Add(new SessionItem
                    {
                        Id = "custom:" + StableId(file),
                        Source = "custom_ai",
                        Host = "AI",
                        Title = Path.GetFileNameWithoutExtension(file),
                        Cwd = Path.GetDirectoryName(file),
                        LastActive = info.LastWriteTimeUtc.ToString("o"),
                        LastMessage = FirstLine(text, 200),
                        RawPath = file
                    });
                }
            }
            return result;
        }

        private IEnumerable<SessionItem> ScanKnownAiAppFolders()
        {
            var result = new List<SessionItem>();
            var roots = new List<string>();
            roots.Add(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData));
            roots.Add(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData));
            roots.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "AppData", "LocalLow"));

            var candidates = new List<string>();
            foreach (var root in roots.Where(Directory.Exists))
                candidates.AddRange(FindKnownAiFolders(root, 3).Take(80));

            foreach (var folder in candidates.Distinct(StringComparer.OrdinalIgnoreCase).Take(40))
            {
                string host = KnownAiHostName(folder);
                result.AddRange(ScanGenericAiFolder(folder, host, 120));
            }
            return result;
        }

        private IEnumerable<string> FindKnownAiFolders(string root, int maxDepth)
        {
            var result = new List<string>();
            var queue = new Queue<Tuple<string, int>>();
            queue.Enqueue(Tuple.Create(root, 0));
            while (queue.Count > 0 && result.Count < 120)
            {
                var item = queue.Dequeue();
                string dir = item.Item1;
                int depth = item.Item2;
                if (depth > 0 && LooksLikeAiFolder(dir))
                    result.Add(dir);
                if (depth >= maxDepth) continue;
                IEnumerable<string> children;
                try { children = Directory.GetDirectories(dir); }
                catch { continue; }
                foreach (var child in children.Take(200))
                    queue.Enqueue(Tuple.Create(child, depth + 1));
            }
            return result;
        }

        private bool LooksLikeAiFolder(string path)
        {
            return LooksLikeAiText(path);
        }

        private bool LooksLikeAiText(string text)
        {
            string s = (text ?? "").ToLowerInvariant();
            return s.Contains("doubao") || s.Contains("豆包") || s.Contains("豆包") ||
                   s.Contains("chatgpt") || s.Contains("openai") ||
                   s.Contains("cursor") || s.Contains("windsurf") ||
                   s.Contains("trae") || s.Contains("claude") || s.Contains("anthropic") ||
                   s.Contains("kimi") || s.Contains("moonshot") ||
                   s.Contains("deepseek") || s.Contains("yuanbao") || s.Contains("元宝") ||
                   s.Contains("tongyi") || s.Contains("通义") ||
                   s.Contains("copilot") || s.Contains("gemini") ||
                   s.Contains("poe") || s.Contains("perplexity") || s.Contains("monica") ||
                   s.Contains("秘塔") || s.Contains("metaso") ||
                   s.Contains("文心") || s.Contains("ernie") ||
                   s.Contains("星火") || s.Contains("spark") ||
                   s.Contains("智谱") || s.Contains("chatglm") ||
                   s.Contains("讯飞") || s.Contains("ifly") ||
                   s.Contains("通义千问") || s.Contains("qwen") ||
                   s.Contains("codex");
        }

        private string KnownAiHostName(string path)
        {
            string s = (path ?? "").ToLowerInvariant();
            if (s.Contains("doubao") || s.Contains("豆包")) return "豆包";
            if (s.Contains("chatgpt") || s.Contains("openai")) return "ChatGPT";
            if (s.Contains("cursor")) return "Cursor";
            if (s.Contains("windsurf")) return "Windsurf";
            if (s.Contains("trae")) return "Trae";
            if (s.Contains("claude") || s.Contains("anthropic")) return "Claude";
            if (s.Contains("kimi") || s.Contains("moonshot")) return "Kimi";
            if (s.Contains("deepseek")) return "DeepSeek";
            if (s.Contains("yuanbao") || s.Contains("元宝")) return "元宝";
            if (s.Contains("tongyi") || s.Contains("通义")) return "通义";
            if (s.Contains("copilot")) return "Copilot";
            if (s.Contains("gemini")) return "Gemini";
            if (s.Contains("poe")) return "Poe";
            if (s.Contains("perplexity")) return "Perplexity";
            if (s.Contains("monica")) return "Monica";
            if (s.Contains("metaso") || s.Contains("秘塔")) return "秘塔";
            if (s.Contains("ernie") || s.Contains("文心")) return "文心一言";
            if (s.Contains("spark") || s.Contains("星火") || s.Contains("讯飞") || s.Contains("ifly")) return "讯飞星火";
            if (s.Contains("chatglm") || s.Contains("智谱")) return "智谱清言";
            if (s.Contains("qwen") || s.Contains("通义千问")) return "通义千问";
            if (s.Contains("codex")) return "Codex";
            return "AI";
        }

        private IEnumerable<SessionItem> ScanGenericAiFolder(string folder, string host, int maxFiles)
        {
            var result = new List<SessionItem>();
            var textExts = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { ".jsonl", ".json", ".txt", ".md", ".log" };
            var cacheExts = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { ".sqlite", ".db", ".ldb" };
            IEnumerable<string> files;
            try
            {
                files = Directory.GetFiles(folder, "*.*", SearchOption.AllDirectories)
                    .Where(f => textExts.Contains(Path.GetExtension(f)) || cacheExts.Contains(Path.GetExtension(f)))
                    .OrderByDescending(f => SafeLastWriteUtc(f))
                    .Take(maxFiles);
            }
            catch
            {
                return result;
            }

            foreach (var file in files)
            {
                string ext = Path.GetExtension(file);
                string text = textExts.Contains(ext) ? FirstReadableText(file) : "";
                var info = new FileInfo(file);
                if (string.IsNullOrWhiteSpace(text) && cacheExts.Contains(ext))
                    text = "检测到 " + host + " 本地缓存/数据库文件；格式可能是私有缓存，已作为入口记录。";
                if (string.IsNullOrWhiteSpace(text)) continue;
                result.Add(new SessionItem
                {
                    Id = "knownai:" + StableId(file),
                    Source = "known_ai",
                    Host = host,
                    Title = Path.GetFileNameWithoutExtension(file),
                    Cwd = Path.GetDirectoryName(file),
                    LastActive = info.LastWriteTimeUtc.ToString("o"),
                    LastMessage = FirstLine(text, 200),
                    RawPath = file
                });
            }
            return result;
        }

        private DateTime SafeLastWriteUtc(string file)
        {
            try { return File.GetLastWriteTimeUtc(file); }
            catch { return DateTime.MinValue; }
        }

        private string FirstReadableText(string file)
        {
            try
            {
                var builder = new StringBuilder();
                foreach (var line in File.ReadLines(file, Encoding.UTF8).Take(40))
                {
                    string clean = line.Trim();
                    if (string.IsNullOrWhiteSpace(clean)) continue;
                    clean = Regex.Replace(clean, "[{}\\[\\]\",:]+", " ");
                    clean = Regex.Replace(clean, "\\s+", " ").Trim();
                    if (clean.Length > 8) builder.Append(clean).Append(" ");
                    if (builder.Length > 260) break;
                }
                return builder.ToString().Trim();
            }
            catch
            {
                return "";
            }
        }

        private string StableId(string value)
        {
            unchecked
            {
                ulong hash = 14695981039346656037UL;
                foreach (byte b in Encoding.UTF8.GetBytes(value.ToLowerInvariant()))
                {
                    hash ^= b;
                    hash *= 1099511628211UL;
                }
                return hash.ToString("x");
            }
        }

        private IEnumerable<string> SafeReadLines(string path)
        {
            try { return File.ReadLines(path, Encoding.UTF8); }
            catch { return new string[0]; }
        }

        private string RegexValue(string text, string pattern)
        {
            var match = Regex.Match(text, pattern);
            if (!match.Success) return null;
            return UnescapeJson(match.Groups[1].Value);
        }

        private string UnescapeJson(string value)
        {
            if (value == null) return null;
            return value.Replace("\\n", "\n").Replace("\\r", "\r").Replace("\\t", "\t").Replace("\\\"", "\"").Replace("\\\\", "\\");
        }

        private string FirstLine(string text, int limit)
        {
            if (string.IsNullOrWhiteSpace(text)) return "";
            var line = text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).FirstOrDefault();
            if (line == null) return "";
            line = line.Trim();
            return line.Length > limit ? line.Substring(0, limit) + "..." : line;
        }

        private string AgeText(string iso)
        {
            DateTimeOffset dt;
            if (!DateTimeOffset.TryParse(iso, out dt)) return "?";
            var span = DateTimeOffset.UtcNow - dt.ToUniversalTime();
            if (span.TotalMinutes < 1) return ((int)Math.Max(0, span.TotalSeconds)) + "s";
            if (span.TotalHours < 1) return ((int)span.TotalMinutes) + "m";
            if (span.TotalDays < 1) return ((int)span.TotalHours) + "h";
            return ((int)span.TotalDays) + "d";
        }

        private void InstallStartup()
        {
            string exe = Application.ExecutablePath;
            string content = "@echo off\r\nstart \"\" \"" + exe + "\"\r\n";
            File.WriteAllText(StartupBatPath, content, Encoding.Default);
            MessageBox.Show("已设置为开机自动常驻。", "Pickup");
        }

        private void RemoveStartup()
        {
            if (File.Exists(StartupBatPath)) File.Delete(StartupBatPath);
            MessageBox.Show("已取消开机自动启动。", "Pickup");
        }
    }

    public static class Prompt
    {
        public static string Show(string text, string caption, string value)
        {
            using (var form = new Form())
            using (var label = new Label())
            using (var input = new TextBox())
            using (var ok = new Button())
            using (var cancel = new Button())
            {
                form.Text = caption;
                form.StartPosition = FormStartPosition.CenterParent;
                form.Size = new Size(420, 150);
                form.FormBorderStyle = FormBorderStyle.FixedDialog;
                form.BackColor = Color.FromArgb(246, 247, 249);
                form.Font = new Font("Microsoft YaHei UI", 9F);
                form.MinimizeBox = false;
                form.MaximizeBox = false;
                label.Text = text;
                label.Left = 12;
                label.Top = 12;
                label.Width = 380;
                label.ForeColor = Color.FromArgb(29, 29, 31);
                input.Left = 12;
                input.Top = 38;
                input.Width = 380;
                input.Text = value ?? "";
                ok.Text = "确定";
                ok.Left = 220;
                ok.Top = 74;
                ok.DialogResult = DialogResult.OK;
                ok.FlatStyle = FlatStyle.Flat;
                ok.FlatAppearance.BorderSize = 0;
                ok.BackColor = Color.FromArgb(0, 113, 227);
                ok.ForeColor = Color.White;
                cancel.Text = "取消";
                cancel.Left = 312;
                cancel.Top = 74;
                cancel.DialogResult = DialogResult.Cancel;
                cancel.FlatStyle = FlatStyle.Flat;
                cancel.FlatAppearance.BorderSize = 0;
                cancel.BackColor = Color.FromArgb(232, 234, 238);
                form.Controls.AddRange(new Control[] { label, input, ok, cancel });
                form.AcceptButton = ok;
                form.CancelButton = cancel;
                return form.ShowDialog() == DialogResult.OK ? input.Text : null;
            }
        }
    }

    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += delegate(object sender, System.Threading.ThreadExceptionEventArgs e)
            {
                Debug.WriteLine("Pickup UI exception: " + e.Exception.Message);
            };
            AppDomain.CurrentDomain.UnhandledException += delegate(object sender, UnhandledExceptionEventArgs e)
            {
                var ex = e.ExceptionObject as Exception;
                Debug.WriteLine("Pickup exception: " + (ex == null ? "未知错误" : ex.Message));
            };
            Application.Run(new MainForm());
        }
    }
}
