@echo off
setlocal EnableExtensions
cd /d "%~dp0"

if not exist "PickupWindows.exe" (
  echo PickupWindows.exe was not found. Building from source...
  call build-csharp.bat
  if errorlevel 1 exit /b %errorlevel%
)

start "" "%~dp0PickupWindows.exe"
exit /b 0
